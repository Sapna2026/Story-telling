WEEK 4 STORYTELLING — SUBMISSION PACKAGE

Main file:
- Week_4_Storytelling_FloodGuard_AI.pptx

Presentation:
A 6-slide, non-technical storytelling deck introducing FloodGuard AI:
1. Title and purpose
2. The flood preparedness challenge
3. The proposed solution flow
4. Illustrative dashboard categories and key takeaways
5. Potential value for households, community teams and decision-makers
6. Responsible next steps and closing message

Important accuracy note:
No verified dataset, measured model performance, or field-test results were provided for this deck.
Therefore, slide 4 is explicitly labelled as an illustrative demonstration. It does not claim
real flood predictions, measured percentages, or validated impact. The project is presented as
a proposed decision-support prototype. Official warnings and local-authority instructions must
remain the source for emergency decisions.

Suggested submission note:
"I created a six-slide storytelling presentation explaining the FloodGuard AI concept to a
non-technical audience. I learned how to turn a technical idea into a clear story by starting
with the problem, explaining the solution in simple steps, highlighting its potential value,
and ending with responsible next steps. I also learned the importance of distinguishing
illustrative examples from verified results."
